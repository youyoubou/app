<?php

$string['pluginname'] = 'Moodle App Behat (auto-generated)';
